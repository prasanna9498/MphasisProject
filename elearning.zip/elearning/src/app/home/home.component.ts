import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public courses= [
    {Name: 'C Language', Photo: '../assets/img/course/c.jpg',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'Java App Programming', Photo: '../assets/img/course/java.png',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'C Language', Photo: '../assets/img/course/c.jpg',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'Java App Programming', Photo: '../assets/img/course/java.png',Fee:'Fee: Rs.100', Enroll: 0},
    {Name: 'Java App Programming', Photo: '../assets/img/course/java.png',Fee:'Fee: Rs.100', Enroll: 0},
   
  ];
  
  constructor() { }

  ngOnInit(): void {
  }

}
