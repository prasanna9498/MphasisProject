import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.css']
})
export class MyprofileComponent implements OnInit {

  public profile= [
    {Name: 'ABC', Photo: '../assets/img/course/person.jpg',Dob:'05-05-1997', Gender: 'Male',Phone: '7204195579',Email: 'abc@gmail.com',Username: 'abc29',},
    
   
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
